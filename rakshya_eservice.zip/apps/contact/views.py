# apps/contact/views.py
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from .forms import ContactInquiryForm

@csrf_exempt
def submit_contact_form(request):
    if request.method == "POST":
        form = ContactInquiryForm(request.POST)
        if form.is_valid():
            inquiry = form.save()

            # Prepare email
            subject = "Inquiry Received"
            from_email = "careerguide.academy@gmail.com"
            to_email = ["proxydhakal@gmail.com"]

            # Render HTML content
            from datetime import datetime
            html_content = render_to_string("contact/email_notification.html", {
                "inquiry": inquiry,
                "current_year": datetime.now().year
            })
            # Optional plain text version
            text_content = f"New Inquiry from {inquiry.name} ({inquiry.email})\nService: {inquiry.service}\nMessage: {inquiry.message}"

            # Create EmailMultiAlternatives object
            email = EmailMultiAlternatives(subject, text_content, from_email, to_email)
            email.attach_alternative(html_content, "text/html")
            email.send(fail_silently=True)

            return JsonResponse({"success": True, "message": "Thank you! Your inquiry has been received."})
        else:
            return JsonResponse({"success": False, "errors": form.errors})
    return JsonResponse({"success": False, "message": "Invalid request"})

